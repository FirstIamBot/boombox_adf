/*
* Copyright 2025 NXP
* NXP Proprietary. This software is owned or controlled by NXP and may only be used strictly in
* accordance with the applicable license terms. By expressly accepting such terms or by downloading, installing,
* activating and/or otherwise using the software, you are agreeing that you have read, and that you agree to
* comply with and are bound by, such license terms.  If you do not agree to be bound by the applicable license
* terms, then you may not retain, install, activate or otherwise use the software.
*/

#include "lvgl.h"
#include <stdio.h>
#include "gui_guider.h"
#include "events_init.h"
#include "widgets_init.h"
#include "custom.h"



void setup_scr_Bluetooth(lv_ui *ui)
{
    //Write codes Bluetooth
    ui->Bluetooth = lv_obj_create(NULL);
    lv_obj_set_size(ui->Bluetooth, 320, 240);
    lv_obj_set_scrollbar_mode(ui->Bluetooth, LV_SCROLLBAR_MODE_OFF);

    //Write style for Bluetooth, Part: LV_PART_MAIN, State: LV_STATE_DEFAULT.
    lv_obj_set_style_bg_opa(ui->Bluetooth, 195, LV_PART_MAIN|LV_STATE_DEFAULT);
    lv_obj_set_style_bg_color(ui->Bluetooth, lv_color_hex(0x00d0f5), LV_PART_MAIN|LV_STATE_DEFAULT);
    lv_obj_set_style_bg_grad_dir(ui->Bluetooth, LV_GRAD_DIR_VER, LV_PART_MAIN|LV_STATE_DEFAULT);
    lv_obj_set_style_bg_grad_color(ui->Bluetooth, lv_color_hex(0x2dc2d1), LV_PART_MAIN|LV_STATE_DEFAULT);
    lv_obj_set_style_bg_main_stop(ui->Bluetooth, 75, LV_PART_MAIN|LV_STATE_DEFAULT);
    lv_obj_set_style_bg_grad_stop(ui->Bluetooth, 134, LV_PART_MAIN|LV_STATE_DEFAULT);

    //Write codes Bluetooth_imgbtn_airradio
    ui->Bluetooth_imgbtn_airradio = lv_imgbtn_create(ui->Bluetooth);
    lv_obj_add_flag(ui->Bluetooth_imgbtn_airradio, LV_OBJ_FLAG_CHECKABLE);
    lv_imgbtn_set_src(ui->Bluetooth_imgbtn_airradio, LV_IMGBTN_STATE_RELEASED, NULL, &_radio_alpha_22x22, NULL);
    ui->Bluetooth_imgbtn_airradio_label = lv_label_create(ui->Bluetooth_imgbtn_airradio);
    lv_label_set_text(ui->Bluetooth_imgbtn_airradio_label, "");
    lv_label_set_long_mode(ui->Bluetooth_imgbtn_airradio_label, LV_LABEL_LONG_WRAP);
    lv_obj_align(ui->Bluetooth_imgbtn_airradio_label, LV_ALIGN_CENTER, 0, 0);
    lv_obj_set_style_pad_all(ui->Bluetooth_imgbtn_airradio, 0, LV_STATE_DEFAULT);
    lv_obj_set_pos(ui->Bluetooth_imgbtn_airradio, 25, 30.5);
    lv_obj_set_size(ui->Bluetooth_imgbtn_airradio, 22, 22);

    //Write style for Bluetooth_imgbtn_airradio, Part: LV_PART_MAIN, State: LV_STATE_DEFAULT.
    lv_obj_set_style_text_color(ui->Bluetooth_imgbtn_airradio, lv_color_hex(0x000000), LV_PART_MAIN|LV_STATE_DEFAULT);
    lv_obj_set_style_text_font(ui->Bluetooth_imgbtn_airradio, &lv_font_montserratMedium_12, LV_PART_MAIN|LV_STATE_DEFAULT);
    lv_obj_set_style_text_opa(ui->Bluetooth_imgbtn_airradio, 255, LV_PART_MAIN|LV_STATE_DEFAULT);
    lv_obj_set_style_text_align(ui->Bluetooth_imgbtn_airradio, LV_TEXT_ALIGN_CENTER, LV_PART_MAIN|LV_STATE_DEFAULT);
    lv_obj_set_style_radius(ui->Bluetooth_imgbtn_airradio, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
    lv_obj_set_style_clip_corner(ui->Bluetooth_imgbtn_airradio, true, LV_PART_MAIN|LV_STATE_DEFAULT);
    lv_obj_set_style_shadow_width(ui->Bluetooth_imgbtn_airradio, 0, LV_PART_MAIN|LV_STATE_DEFAULT);

    //Write style for Bluetooth_imgbtn_airradio, Part: LV_PART_MAIN, State: LV_STATE_PRESSED.
    lv_obj_set_style_img_recolor_opa(ui->Bluetooth_imgbtn_airradio, 0, LV_PART_MAIN|LV_STATE_PRESSED);
    lv_obj_set_style_img_opa(ui->Bluetooth_imgbtn_airradio, 255, LV_PART_MAIN|LV_STATE_PRESSED);
    lv_obj_set_style_text_color(ui->Bluetooth_imgbtn_airradio, lv_color_hex(0xFF33FF), LV_PART_MAIN|LV_STATE_PRESSED);
    lv_obj_set_style_text_font(ui->Bluetooth_imgbtn_airradio, &lv_font_montserratMedium_12, LV_PART_MAIN|LV_STATE_PRESSED);
    lv_obj_set_style_text_opa(ui->Bluetooth_imgbtn_airradio, 255, LV_PART_MAIN|LV_STATE_PRESSED);
    lv_obj_set_style_shadow_width(ui->Bluetooth_imgbtn_airradio, 0, LV_PART_MAIN|LV_STATE_PRESSED);

    //Write style for Bluetooth_imgbtn_airradio, Part: LV_PART_MAIN, State: LV_STATE_CHECKED.
    lv_obj_set_style_img_recolor_opa(ui->Bluetooth_imgbtn_airradio, 0, LV_PART_MAIN|LV_STATE_CHECKED);
    lv_obj_set_style_img_opa(ui->Bluetooth_imgbtn_airradio, 255, LV_PART_MAIN|LV_STATE_CHECKED);
    lv_obj_set_style_text_color(ui->Bluetooth_imgbtn_airradio, lv_color_hex(0xFF33FF), LV_PART_MAIN|LV_STATE_CHECKED);
    lv_obj_set_style_text_font(ui->Bluetooth_imgbtn_airradio, &lv_font_montserratMedium_12, LV_PART_MAIN|LV_STATE_CHECKED);
    lv_obj_set_style_text_opa(ui->Bluetooth_imgbtn_airradio, 255, LV_PART_MAIN|LV_STATE_CHECKED);
    lv_obj_set_style_shadow_width(ui->Bluetooth_imgbtn_airradio, 0, LV_PART_MAIN|LV_STATE_CHECKED);

    //Write style for Bluetooth_imgbtn_airradio, Part: LV_PART_MAIN, State: LV_IMGBTN_STATE_RELEASED.
    lv_obj_set_style_img_recolor_opa(ui->Bluetooth_imgbtn_airradio, 0, LV_PART_MAIN|LV_IMGBTN_STATE_RELEASED);
    lv_obj_set_style_img_opa(ui->Bluetooth_imgbtn_airradio, 255, LV_PART_MAIN|LV_IMGBTN_STATE_RELEASED);

    //Write codes Bluetooth_imgbtn_webradio
    ui->Bluetooth_imgbtn_webradio = lv_imgbtn_create(ui->Bluetooth);
    lv_obj_add_flag(ui->Bluetooth_imgbtn_webradio, LV_OBJ_FLAG_CHECKABLE);
    lv_imgbtn_set_src(ui->Bluetooth_imgbtn_webradio, LV_IMGBTN_STATE_RELEASED, NULL, &_website_alpha_22x22, NULL);
    ui->Bluetooth_imgbtn_webradio_label = lv_label_create(ui->Bluetooth_imgbtn_webradio);
    lv_label_set_text(ui->Bluetooth_imgbtn_webradio_label, "");
    lv_label_set_long_mode(ui->Bluetooth_imgbtn_webradio_label, LV_LABEL_LONG_WRAP);
    lv_obj_align(ui->Bluetooth_imgbtn_webradio_label, LV_ALIGN_CENTER, 0, 0);
    lv_obj_set_style_pad_all(ui->Bluetooth_imgbtn_webradio, 0, LV_STATE_DEFAULT);
    lv_obj_set_pos(ui->Bluetooth_imgbtn_webradio, 266, 30);
    lv_obj_set_size(ui->Bluetooth_imgbtn_webradio, 22, 22);

    //Write style for Bluetooth_imgbtn_webradio, Part: LV_PART_MAIN, State: LV_STATE_DEFAULT.
    lv_obj_set_style_text_color(ui->Bluetooth_imgbtn_webradio, lv_color_hex(0x000000), LV_PART_MAIN|LV_STATE_DEFAULT);
    lv_obj_set_style_text_font(ui->Bluetooth_imgbtn_webradio, &lv_font_montserratMedium_12, LV_PART_MAIN|LV_STATE_DEFAULT);
    lv_obj_set_style_text_opa(ui->Bluetooth_imgbtn_webradio, 255, LV_PART_MAIN|LV_STATE_DEFAULT);
    lv_obj_set_style_text_align(ui->Bluetooth_imgbtn_webradio, LV_TEXT_ALIGN_CENTER, LV_PART_MAIN|LV_STATE_DEFAULT);
    lv_obj_set_style_radius(ui->Bluetooth_imgbtn_webradio, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
    lv_obj_set_style_clip_corner(ui->Bluetooth_imgbtn_webradio, true, LV_PART_MAIN|LV_STATE_DEFAULT);
    lv_obj_set_style_shadow_width(ui->Bluetooth_imgbtn_webradio, 0, LV_PART_MAIN|LV_STATE_DEFAULT);

    //Write style for Bluetooth_imgbtn_webradio, Part: LV_PART_MAIN, State: LV_STATE_PRESSED.
    lv_obj_set_style_img_recolor_opa(ui->Bluetooth_imgbtn_webradio, 0, LV_PART_MAIN|LV_STATE_PRESSED);
    lv_obj_set_style_img_opa(ui->Bluetooth_imgbtn_webradio, 255, LV_PART_MAIN|LV_STATE_PRESSED);
    lv_obj_set_style_text_color(ui->Bluetooth_imgbtn_webradio, lv_color_hex(0xFF33FF), LV_PART_MAIN|LV_STATE_PRESSED);
    lv_obj_set_style_text_font(ui->Bluetooth_imgbtn_webradio, &lv_font_montserratMedium_12, LV_PART_MAIN|LV_STATE_PRESSED);
    lv_obj_set_style_text_opa(ui->Bluetooth_imgbtn_webradio, 255, LV_PART_MAIN|LV_STATE_PRESSED);
    lv_obj_set_style_shadow_width(ui->Bluetooth_imgbtn_webradio, 0, LV_PART_MAIN|LV_STATE_PRESSED);

    //Write style for Bluetooth_imgbtn_webradio, Part: LV_PART_MAIN, State: LV_STATE_CHECKED.
    lv_obj_set_style_img_recolor_opa(ui->Bluetooth_imgbtn_webradio, 0, LV_PART_MAIN|LV_STATE_CHECKED);
    lv_obj_set_style_img_opa(ui->Bluetooth_imgbtn_webradio, 255, LV_PART_MAIN|LV_STATE_CHECKED);
    lv_obj_set_style_text_color(ui->Bluetooth_imgbtn_webradio, lv_color_hex(0xFF33FF), LV_PART_MAIN|LV_STATE_CHECKED);
    lv_obj_set_style_text_font(ui->Bluetooth_imgbtn_webradio, &lv_font_montserratMedium_12, LV_PART_MAIN|LV_STATE_CHECKED);
    lv_obj_set_style_text_opa(ui->Bluetooth_imgbtn_webradio, 255, LV_PART_MAIN|LV_STATE_CHECKED);
    lv_obj_set_style_shadow_width(ui->Bluetooth_imgbtn_webradio, 0, LV_PART_MAIN|LV_STATE_CHECKED);

    //Write style for Bluetooth_imgbtn_webradio, Part: LV_PART_MAIN, State: LV_IMGBTN_STATE_RELEASED.
    lv_obj_set_style_img_recolor_opa(ui->Bluetooth_imgbtn_webradio, 0, LV_PART_MAIN|LV_IMGBTN_STATE_RELEASED);
    lv_obj_set_style_img_opa(ui->Bluetooth_imgbtn_webradio, 255, LV_PART_MAIN|LV_IMGBTN_STATE_RELEASED);

    //Write codes Bluetooth_label_BT
    ui->Bluetooth_label_BT = lv_label_create(ui->Bluetooth);
    lv_label_set_text(ui->Bluetooth_label_BT, "" LV_SYMBOL_BLUETOOTH " ");
    lv_label_set_long_mode(ui->Bluetooth_label_BT, LV_LABEL_LONG_WRAP);
    lv_obj_set_pos(ui->Bluetooth_label_BT, 135, 13);
    lv_obj_set_size(ui->Bluetooth_label_BT, 46, 57);

    //Write style for Bluetooth_label_BT, Part: LV_PART_MAIN, State: LV_STATE_DEFAULT.
    lv_obj_set_style_border_width(ui->Bluetooth_label_BT, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
    lv_obj_set_style_radius(ui->Bluetooth_label_BT, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
    lv_obj_set_style_text_color(ui->Bluetooth_label_BT, lv_color_hex(0x000000), LV_PART_MAIN|LV_STATE_DEFAULT);
    lv_obj_set_style_text_font(ui->Bluetooth_label_BT, &lv_font_montserratMedium_56, LV_PART_MAIN|LV_STATE_DEFAULT);
    lv_obj_set_style_text_opa(ui->Bluetooth_label_BT, 255, LV_PART_MAIN|LV_STATE_DEFAULT);
    lv_obj_set_style_text_letter_space(ui->Bluetooth_label_BT, 2, LV_PART_MAIN|LV_STATE_DEFAULT);
    lv_obj_set_style_text_line_space(ui->Bluetooth_label_BT, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
    lv_obj_set_style_text_align(ui->Bluetooth_label_BT, LV_TEXT_ALIGN_CENTER, LV_PART_MAIN|LV_STATE_DEFAULT);
    lv_obj_set_style_bg_opa(ui->Bluetooth_label_BT, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
    lv_obj_set_style_pad_top(ui->Bluetooth_label_BT, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
    lv_obj_set_style_pad_right(ui->Bluetooth_label_BT, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
    lv_obj_set_style_pad_bottom(ui->Bluetooth_label_BT, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
    lv_obj_set_style_pad_left(ui->Bluetooth_label_BT, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
    lv_obj_set_style_shadow_width(ui->Bluetooth_label_BT, 0, LV_PART_MAIN|LV_STATE_DEFAULT);

    //Write codes Bluetooth_label_bt_song
    ui->Bluetooth_label_bt_song = lv_label_create(ui->Bluetooth);
    lv_label_set_text(ui->Bluetooth_label_bt_song, "AC/DC  Hell Bell");
    lv_label_set_long_mode(ui->Bluetooth_label_bt_song, LV_LABEL_LONG_SCROLL_CIRCULAR);
    lv_obj_set_pos(ui->Bluetooth_label_bt_song, 6, 95);
    lv_obj_set_size(ui->Bluetooth_label_bt_song, 307, 20);

    //Write style for Bluetooth_label_bt_song, Part: LV_PART_MAIN, State: LV_STATE_DEFAULT.
    lv_obj_set_style_border_width(ui->Bluetooth_label_bt_song, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
    lv_obj_set_style_radius(ui->Bluetooth_label_bt_song, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
    lv_obj_set_style_text_color(ui->Bluetooth_label_bt_song, lv_color_hex(0x000000), LV_PART_MAIN|LV_STATE_DEFAULT);
    lv_obj_set_style_text_font(ui->Bluetooth_label_bt_song, &lv_font_montserratMedium_16, LV_PART_MAIN|LV_STATE_DEFAULT);
    lv_obj_set_style_text_opa(ui->Bluetooth_label_bt_song, 255, LV_PART_MAIN|LV_STATE_DEFAULT);
    lv_obj_set_style_text_letter_space(ui->Bluetooth_label_bt_song, 2, LV_PART_MAIN|LV_STATE_DEFAULT);
    lv_obj_set_style_text_line_space(ui->Bluetooth_label_bt_song, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
    lv_obj_set_style_text_align(ui->Bluetooth_label_bt_song, LV_TEXT_ALIGN_CENTER, LV_PART_MAIN|LV_STATE_DEFAULT);
    lv_obj_set_style_bg_opa(ui->Bluetooth_label_bt_song, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
    lv_obj_set_style_pad_top(ui->Bluetooth_label_bt_song, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
    lv_obj_set_style_pad_right(ui->Bluetooth_label_bt_song, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
    lv_obj_set_style_pad_bottom(ui->Bluetooth_label_bt_song, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
    lv_obj_set_style_pad_left(ui->Bluetooth_label_bt_song, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
    lv_obj_set_style_shadow_width(ui->Bluetooth_label_bt_song, 0, LV_PART_MAIN|LV_STATE_DEFAULT);

    //The custom code of Bluetooth.


    //Update current screen layout.
    lv_obj_update_layout(ui->Bluetooth);

    //Init events for screen.
    events_init_Bluetooth(ui);
}
